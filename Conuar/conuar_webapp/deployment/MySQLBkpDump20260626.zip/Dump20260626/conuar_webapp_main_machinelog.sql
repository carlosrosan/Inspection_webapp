CREATE DATABASE  IF NOT EXISTS `conuar_webapp` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `conuar_webapp`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: conuar_webapp
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `main_machinelog`
--

DROP TABLE IF EXISTS `main_machinelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `main_machinelog` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `log_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` datetime(6) NOT NULL,
  `machine_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `main_machinelog_machine_id_7c8b8f1f` (`machine_id`),
  CONSTRAINT `main_machinelog_machine_id_7c8b8f1f_fk_main_inspectionmachine_id` FOREIGN KEY (`machine_id`) REFERENCES `main_inspectionmachine` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_machinelog`
--

LOCK TABLES `main_machinelog` WRITE;
/*!40000 ALTER TABLE `main_machinelog` DISABLE KEYS */;
INSERT INTO `main_machinelog` VALUES (1,'inspection_complete','Sistema de análisis funcionando normalmente','2025-10-03 14:20:03.969931',1),(2,'status_change','Calibración completada exitosamente','2025-10-03 14:20:03.973931',1),(3,'inspection_complete','Sistema de análisis funcionando normalmente','2025-10-03 14:20:03.975929',1),(4,'inspection_complete','Verificación de calidad en progreso','2025-10-03 14:20:03.979457',1),(5,'status_change','Máquina iniciada correctamente','2025-10-03 14:20:03.981456',1),(6,'inspection_complete','Inspección de muestra completada','2025-10-03 14:20:03.984127',1),(7,'status_change','Verificación de calidad en progreso','2025-10-03 14:20:03.985779',1),(8,'status_change','Máquina iniciada correctamente','2025-10-03 14:20:03.985779',1),(9,'inspection_complete','Inspección de muestra completada','2025-10-03 14:20:03.985779',1),(10,'status_change','Calibración completada exitosamente','2025-10-03 14:20:03.985779',1);
/*!40000 ALTER TABLE `main_machinelog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-26 11:45:14
