CREATE DATABASE  IF NOT EXISTS `conuar_webapp` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `conuar_webapp`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: conuar_webapp
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` bigint NOT NULL,
  `codename` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  KEY `auth_permission_content_type_id_2f476e4b` (`content_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add permission',1,'add_permission'),(2,'Can change permission',1,'change_permission'),(3,'Can delete permission',1,'delete_permission'),(4,'Can view permission',1,'view_permission'),(5,'Can add group',2,'add_group'),(6,'Can change group',2,'change_group'),(7,'Can delete group',2,'delete_group'),(8,'Can view group',2,'view_group'),(9,'Can add content type',3,'add_contenttype'),(10,'Can change content type',3,'change_contenttype'),(11,'Can delete content type',3,'delete_contenttype'),(12,'Can view content type',3,'view_contenttype'),(13,'Can add User',4,'add_user'),(14,'Can change User',4,'change_user'),(15,'Can delete User',4,'delete_user'),(16,'Can view User',4,'view_user'),(17,'Can add Inspección',5,'add_inspection'),(18,'Can change Inspección',5,'change_inspection'),(19,'Can delete Inspección',5,'delete_inspection'),(20,'Can view Inspección',5,'view_inspection'),(21,'Can add Máquina de Inspección',6,'add_inspectionmachine'),(22,'Can change Máquina de Inspección',6,'change_inspectionmachine'),(23,'Can delete Máquina de Inspección',6,'delete_inspectionmachine'),(24,'Can view Máquina de Inspección',6,'view_inspectionmachine'),(25,'Can add Configuración del Sistema',7,'add_systemconfiguration'),(26,'Can change Configuración del Sistema',7,'change_systemconfiguration'),(27,'Can delete Configuración del Sistema',7,'delete_systemconfiguration'),(28,'Can view Configuración del Sistema',7,'view_systemconfiguration'),(29,'Can add Lectura PLC',8,'add_plcreading'),(30,'Can change Lectura PLC',8,'change_plcreading'),(31,'Can delete Lectura PLC',8,'delete_plcreading'),(32,'Can view Lectura PLC',8,'view_plcreading'),(33,'Can add PLC Data Raw',9,'add_plcdataraw'),(34,'Can change PLC Data Raw',9,'change_plcdataraw'),(35,'Can delete PLC Data Raw',9,'delete_plcdataraw'),(36,'Can view PLC Data Raw',9,'view_plcdataraw'),(37,'Can add Registro de Máquina',10,'add_machinelog'),(38,'Can change Registro de Máquina',10,'change_machinelog'),(39,'Can delete Registro de Máquina',10,'delete_machinelog'),(40,'Can view Registro de Máquina',10,'view_machinelog'),(41,'Can add Evento PLC de Inspección',11,'add_inspectionplcevent'),(42,'Can change Evento PLC de Inspección',11,'change_inspectionplcevent'),(43,'Can delete Evento PLC de Inspección',11,'delete_inspectionplcevent'),(44,'Can view Evento PLC de Inspección',11,'view_inspectionplcevent'),(45,'Can add Foto de Inspección',12,'add_inspectionphoto'),(46,'Can change Foto de Inspección',12,'change_inspectionphoto'),(47,'Can delete Foto de Inspección',12,'delete_inspectionphoto'),(48,'Can view Foto de Inspección',12,'view_inspectionphoto');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-26 11:45:14
